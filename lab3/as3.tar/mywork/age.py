# Allow to drink only when the person is at least 22 years old
age = int(input("How old are you: "));
if age>=22:
	print("OK. Would you like Vodka?");
else:
	print("Hi kid. How about lemonade?"); 
